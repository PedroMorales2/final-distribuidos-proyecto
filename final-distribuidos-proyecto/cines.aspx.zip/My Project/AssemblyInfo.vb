﻿Imports System.Reflection
Imports System.Runtime.InteropServices

' La información general sobre un ensamblado se controla mediante el siguiente 
' conjunto de atributos. Cambie los valores de estos atributos para modificar la información
' asociada a un ensamblado.

' Revisar los valores de los atributos del ensamblado
<Assembly: AssemblyTitle("final_distribuidos_proyecto")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("final_distribuidos_proyecto")>
<Assembly: AssemblyCopyright("Copyright ©  2024")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'El siguiente GUID es para el Id. typelib cuando este proyecto esté expuesto a COM
<Assembly: Guid("86eba406-cdf8-4e5f-b57b-d147cb32a2f8")>

' La información de versión de un ensamblado consta de los siguientes cuatro valores:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
